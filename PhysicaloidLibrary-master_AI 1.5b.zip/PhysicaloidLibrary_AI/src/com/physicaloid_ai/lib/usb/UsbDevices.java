package com.physicaloid_ai.lib.usb;

public class UsbDevices {

  public static final int NoDriver = 0;
  public static final int CDCACM = 1;
  public static final int CH34X = 2;
  public static final int CP210X = 3;
  public static final int FTDI = 4;
  public static final int PL2303 = 5;

/*  
    Rak 221009
    Definition file for USB devices ID and PID to select driver
    Some CDCACM devices are included only for reference. They would be slected
    anyway by the default selection CDCACM
    
    Note DCDUINO WCH must have double def of combinations vid,pid. dont know which is valid!
    This gives sane result as old version.
    230120 Add XIAO
*/
  
  public static final int device [][] = {
  //    VID     PID     Driver        PID=0 -> Use driver fo all PID,  
    { 0x2341,      0,   CDCACM } ,    // Arduino
    { 0x0403,      0,   FTDI   } ,    //FTDI
    { 0x10C4, 0x8C0F,   CDCACM } ,    //Silicon Labs CDCACM
    { 0x10C4,      0,   CP210X } ,    //CP2104
//  { 0x10C4, 0xEA60,   CP210X } ,    //CP2104 Default VID/PID
    { 0x067B,      0,   PL2303 } ,
    { 0x4348, 0x5523,   CH34X  } ,    //DCDUINO WCH
    { 0x4348, 0x7523,   CH34X  } ,
    { 0x1A86, 0x5323,   CH34X  } ,    //DCDUIO WCH
    { 0x1A86, 0x7523,   CH34X  } ,  
    { 0x1A86, 0x7522,   CH34X  } ,    //LD-C100 USB TO CT-62 For Yaesu  
    { 0x155A,      0,   CP210X } ,    //ELDAT CP210X
    { 0x16D0,      0,   CDCACM } ,    //ATTINY85  FREE VID (PID=0x087E)
    { 0x0483,      0,   CDCACM } ,    //OPEN_CR, Bluepill
    { 0x16c0,      0,   CDCACM } ,    //Teensy
    { 0x0483,      0,   CDCACM } ,    //Feather M0
    { 0x2886, 0x802F,   CDCACM }      //XIAO
  };

  public static int GetDriver ( int vid, int pid) {
     // Return driver for vid, pid or for vid, pid=0
  
     for (int row =0; row < device.length; row ++) {   
        if ((device[row][0] == vid) && (device[row][1] == pid)) return (device[row][2]); // vid, pid defined
     }
     
     for (int row =0; row < device.length; row ++) {
        if ((device[row][0] == vid) && (device[row][1] == 0)) return (device[row][2]);  // only vid defined
     }
  
     return  NoDriver;
  }


}

