/*
    
 * Licensed under the Apache License, Version 2.0 (the "License")

*/


package com.physicaloid_ai.lib.usb.driver.uart;

import android.content.Context;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbRequest;
import android.util.Log;
import com.physicaloid_ai.lib.Physicaloid;

import com.physicaloid_ai.lib.framework.SerialCommunicator;
import com.physicaloid_ai.lib.usb.UsbCdcConnection;
import com.physicaloid_ai.misc.RingBuffer;
import com.physicaloid_ai.BuildConfig;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/*
   200921 Rak Change controltype INTERFACE -> DEVICE
              Remove default baudrate, use settings in UartConfig
              Rewrite baudrate, control and line settings to make it work
   201119 Rak Add setting for USB transfers
   201120     Add bytesInReadBuffer()
              Remove ref to lisener, add debug config
   220527     Temp include alt VID  
   220616     Add vid, pid to constructor, remove redundent code in open   
   221017     Replace VidPid      
*/
/*     cp2102 64B bulktransfer, 640B Wr buffer  512B Rd buffer */

public class UartCp210x extends SerialCommunicator {

        private static final String TAG = UartCp210x.class.getSimpleName();
        private boolean DEBUG_SHOW = true && BuildConfig.DEBUG;
//        private static final int DEFAULT_BAUDRATE = 9600;
        private UsbCdcConnection mUsbConnetionManager;
        private UartConfig mUartConfig;
        private static final int RING_BUFFER_SIZE = 1024;
//        private static final int USB_READ_BUFFER_SIZE = 256; not used
        private static final int USB_WRITE_BUFFER_SIZE = 128;
        private static final int USB_BULK_WRITE_TIMEOUT = 500;
        private RingBuffer mBuffer;
        private boolean mReadThreadStop = true;
        private UsbDeviceConnection mConnection;
        private UsbEndpoint mEndpointIn;
        private UsbEndpoint mEndpointOut;
        private boolean isOpened;
        private int mVid = 0;
        private int mPid = 0;

        /*
         * Config request types
         */
        private static final byte REQTYPE_HOST_TO_DEVICE = (byte) 0x40;
        private static final byte REQTYPE_DEVICE_TO_HOST = (byte) 0xc0;

        /*
         * Config request codes
         */
        private static final byte CP210X_IFC_ENABLE = 0x00;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_BAUDDIV = 0x01;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_BAUDDIV = 0x02;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_LINE_CTL = 0x03;
        private static final byte CP210X_GET_LINE_CTL = 0x04;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_BREAK = 0x05;
        @SuppressWarnings("unused")
        private static final byte CP210X_IMM_CHAR = 0x06;
        private static final byte CP210X_SET_MHS = 0x07;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_MDMSTS = 0x08;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_XON = 0x09;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_XOFF = 0x0A;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_EVENTMASK = 0x0B;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_EVENTMASK = 0x0C;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_CHAR = 0x0D;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_CHARS = 0x0E;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_PROPS = 0x0F;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_COMM_STATUS = 0x10;
        @SuppressWarnings("unused")
        private static final byte CP210X_RESET = 0x11;
        @SuppressWarnings("unused")
        private static final byte CP210X_PURGE = 0x12;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_FLOW = 0x13;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_FLOW = 0x14;
        @SuppressWarnings("unused")
        private static final byte CP210X_EMBED_EVENTS = 0x15;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_EVENTSTATE = 0x16;
        @SuppressWarnings("unused")
        private static final byte CP210X_SET_CHARS = 0x19;
        @SuppressWarnings("unused")
        private static final byte CP210X_GET_BAUDRATE = 0x1D;
        private static final byte CP210X_SET_BAUDRATE = 0x1E;

        /*
         * CP210X_IFC_ENABLE
         */
        private static final int UART_ENABLE = 0x0001;
        private static final int UART_DISABLE = 0x0000;

        /*
         * CP210X_(SET|GET)_BAUDDIV
         */
        @SuppressWarnings("unused")
        private static final int BAUD_RATE_GEN_FREQ = 0x384000;

        /*
         * CP210X_(SET|GET)_LINE_CTL
         */
        private static final int BITS_DATA_MASK = 0x0f00;
        @SuppressWarnings("unused")
        private static final int BITS_DATA_5 = 0x0500;
        @SuppressWarnings("unused")
        private static final int BITS_DATA_6 = 0x0600;
        ;
    private static final int BITS_DATA_7 = 0x0700;
        private static final int BITS_DATA_8 = 0x0800;
        @SuppressWarnings("unused")
        private static final int BITS_DATA_9 = 0x0900;
        private static final int BITS_PARITY_MASK = 0x00f0;
        private static final int BITS_PARITY_NONE = 0x0000;
        private static final int BITS_PARITY_ODD = 0x0010;
        private static final int BITS_PARITY_EVEN = 0x0020;
        private static final int BITS_PARITY_MARK = 0x0030;
        private static final int BITS_PARITY_SPACE = 0x0040;
        private static final int BITS_STOP_MASK = 0x000f;
        private static final int BITS_STOP_1 = 0x0000;
        private static final int BITS_STOP_1_5 = 0x0001;
        private static final int BITS_STOP_2 = 0x0002;

        /*
         * CP210X_SET_BREAK
         */
        @SuppressWarnings("unused")
        private static final int BREAK_ON = 0x0001;
        @SuppressWarnings("unused")
        private static final int BREAK_OFF = 0x0000;

        /*
         * CP210X_(SET_MHS|GET_MDMSTS)
         */
        private static final int CONTROL_DTR = 0x0001;
        private static final int CONTROL_RTS = 0x0002;
        @SuppressWarnings("unused")
        private static final int CONTROL_CTS = 0x0010;
        @SuppressWarnings("unused")
        private static final int CONTROL_DSR = 0x0020;
        @SuppressWarnings("unused")
        private static final int CONTROL_RING = 0x0040;
        @SuppressWarnings("unused")
        private static final int CONTROL_DCD = 0x0080;
        private static final int CONTROL_WRITE_DTR = 0x0100;
        private static final int CONTROL_WRITE_RTS = 0x0200;


        private static final int CP210X_MHS_RTS_ON = 0x202;
        private static final int CP210X_MHS_RTS_OFF = 0x200;
        private static final int CP210X_MHS_DTR_ON = 0x101;
        private static final int CP210X_MHS_DTR_OFF = 0x100;



        public UartCp210x(Context context, int Vid, int Pid) {
                super(context);
                mUsbConnetionManager = new UsbCdcConnection(context);
                mUartConfig = new UartConfig();
                mBuffer = new RingBuffer(RING_BUFFER_SIZE);
                mVid = Vid;
                mPid = Pid;
                isOpened = false;
        }

        @Override
        public boolean open() {
                if(open(mVid, mPid)) return true; 
                return false;
        }

        public boolean open(int vid, int pid) {
                if(mUsbConnetionManager.open(vid,pid)) {
                        mConnection = mUsbConnetionManager.getConnection();
                        mEndpointIn = mUsbConnetionManager.getEndpointIn();
                        mEndpointOut = mUsbConnetionManager.getEndpointOut();
                        if(!init()) {
                                return false;
                        }
/*
                        if(!setBaudrate(DEFAULT_BAUDRATE)) {
                                return false;
                        }
*/
                        mBuffer.clear();
                        startRead();
                        isOpened = true;
                        return true;
                }
                return false;
        }

        @Override
        public boolean close() {
                stopRead();
                isOpened = false;
                cp210xUsbDisable();
                return mUsbConnetionManager.close();
        }

        @Override
        public int read(byte[] buf, int size) {
                return mBuffer.get(buf, size);
        }

        @Override
        public int write(byte[] buf, int size) {
                if(buf == null) {
                        return 0;
                }
                int offset = 0;
                int write_size;
                int written_size;
                byte[] wbuf = new byte[USB_WRITE_BUFFER_SIZE];

                while(offset < size) {
                        write_size = USB_WRITE_BUFFER_SIZE;

                        if(offset + write_size > size) {
                                write_size = size - offset;
                        }
                        System.arraycopy(buf, offset, wbuf, 0, write_size);

                        written_size = mConnection.bulkTransfer(mEndpointOut, wbuf, write_size, USB_BULK_WRITE_TIMEOUT);

                        if(written_size < 0) {
                                return -1;
                        }
                        offset += written_size;
                }

                return offset;
        }

        private void stopRead() {
                mReadThreadStop = true;
        }

        private void startRead() {
                if(mReadThreadStop) {
                        mReadThreadStop = false;
                        new Thread(mLoop).start();
                }
        }
        private Runnable mLoop = new Runnable() {

                @Override
                public void run() {
                        int len;
                        // byte[] rbuf = new byte[USB_READ_BUFFER_SIZE];
                        byte[] rbuf = new byte[mEndpointIn.getMaxPacketSize()];
                        android.os.Process.setThreadPriority(-20);
                        UsbRequest response;
                        UsbRequest request = new UsbRequest();
                        request.initialize(mConnection, mEndpointIn);
                        ByteBuffer buf = ByteBuffer.wrap(rbuf);
                        for(;;) {// this is the main loop for transferring
                                len = 0;
                                if(request.queue(buf, rbuf.length)) {
                                        response = mConnection.requestWait();
                                        if(response != null) {
                                                len = buf.position();
                                        }
                                        if(len > 0) {
                                                mBuffer.add(rbuf, len);
                                                onRead(len);
                                        } else if(mBuffer.getBufferdLength() > 0) {
                                                onRead(mBuffer.getBufferdLength());
                                        } else if(mBuffer.getBufferdLength() > 0) {
                                                onRead(mBuffer.getBufferdLength());
                                        }


                                }

                                if(mReadThreadStop) {
                                        return;
                                }

                                try {
                                        Thread.sleep(1);
                                } catch(InterruptedException e) {
                                }

                        }
                } // end of run()
        }; // end of runnable


        /**
         * Initializes CP210x communication
         *
         * @return true : successful, false : fail
         */
        private boolean init() {
                int ret = cp210xUsbEnable();
                if(ret < 0) {
                        return false;
                }
                return true;
        }

        @Override
        public boolean isOpened() {
                return isOpened;
        }

        @Override
        public boolean isConnected() {
                return isOpened;  //for serial OTG
        }

        /**
         * Enables CP210x
         *
         * @return positive value : successful, negative value : fail
         */
        private int cp210xUsbEnable() {
                if(mConnection == null) {
                        return -1;
                }
                return mConnection.controlTransfer(
                        REQTYPE_HOST_TO_DEVICE,
                        CP210X_IFC_ENABLE,
                        UART_ENABLE,
                        0,
                        null,
                        0,
                        100);
        }

        /**
         * Disables CP210x
         *
         * @return positive value : successful, negative value : fail
         */
        private int cp210xUsbDisable() {
                if(mConnection == null) {
                        return -1;
                }
                return mConnection.controlTransfer(
                        REQTYPE_HOST_TO_DEVICE,
                        CP210X_IFC_ENABLE,
                        UART_DISABLE,
                        0,
                        null,
                        0,
                        100);
        }

        /**
         * Gets configurations from CP210x
         *
         * @param request request id
         * @param buf gotten buffer
         * @param size size of getting buffer
         * @return positive value : successful, negative value : fail
         */
/* Not used
        private int cp210xGetConfig(int request, byte[] buf, int size) {
                if(mConnection == null) {
                        return -1;
                }
                int ret = mConnection.controlTransfer(
                        REQTYPE_DEVICE_TO_HOST,
                        request,
                        0x0000,
                        0,
                        buf,
                        size,
                        100);
                return ret;
        }
*/
        /**
         * Sets configurations from CP210x
         *
         * @param request request id
         * @param buf set buffer
         * @param size size of sending buffer
         * @return
         */
/* Not used
        private int cp210xSetConfig(int request, byte[] buf, int size) {
                if(mConnection == null) {
                        return -1;
                }
                int ret = mConnection.controlTransfer(
                        REQTYPE_HOST_TO_DEVICE,
                        request,
                        0x0000,
                        0,
                        buf,
                        size,
                        100);
                return ret;
        }
*/
/*
        set control command as a int value or as a byte array
*/
        private boolean setControlCommand(int request, int value, byte[] data)
        {
           int dataLength = 0;
           if(data != null)
           {
               dataLength = data.length;
           }
           int response = mConnection.controlTransfer(REQTYPE_HOST_TO_DEVICE, request, value, 0x0000, data, dataLength, 100);
           if(DEBUG_SHOW) Log.d(TAG,"Control Transfer Response: " + response);

           return response>=0;
       }

/*
       set parameters for line control
*/
       private boolean setLineControl( int dataBits, int parity, int stopBits) {

             int val=0;   
             if(DEBUG_SHOW) Log.d(TAG, "setLineControl databits="+dataBits+" parity="+parity+" stpBits="+stopBits);
             val= ((dataBits&0x0f) << 8) + ((parity&0x03) << 4) + (stopBits&0x03);       
             return setControlCommand(CP210X_SET_LINE_CTL, val, null);

       }

/*
        set parameters from UartConfig
*/

        @Override
        public boolean setUartConfig(UartConfig config) {
                if(DEBUG_SHOW) Log.d(TAG, "setUartConfig");
                
                boolean ret;
                ret = setBaudrate(config.baudrate);
                ret &= setLineControl ( config.dataBits, config.parity, config.stopBits);
                ret &= setDtrRts(config.dtrOn, config.rtsOn);

               return ret;
        }

/*
       set baudrate, 300-115200
*/
       @Override
       public boolean setBaudrate(int baudrate)  {
           if(DEBUG_SHOW) Log.d(TAG, "setBaudrate="+baudrate);
           byte[] data = new byte[] {
                (byte) (baudrate & 0xff),
                (byte) (baudrate >> 8 & 0xff),
                (byte) (baudrate >> 16 & 0xff),
                (byte) (baudrate >> 24 & 0xff)
           };
           if (setControlCommand(CP210X_SET_BAUDRATE, 0, data)){
              mUartConfig.baudrate=baudrate;
              return true;
           }
           return false;
       }

/*
       set nr data bits, 5,6,7,8
*/
       @Override
       public boolean setDataBits(int dataBits)
       {
          if(DEBUG_SHOW) Log.d(TAG, "setDataBits");
          if (setLineControl (dataBits, mUartConfig.parity, mUartConfig.stopBits)) {
             mUartConfig.dataBits=dataBits;
             return true;
          }
          return false;
       }
 
/*
       set parity 0=none, 1=odd, 2=even, (3=mark, 4=space)  
*/       
       @Override
       public boolean setParity(int parity)
       {
          if(DEBUG_SHOW) Log.d(TAG, "setParity");
          if (setLineControl (mUartConfig.dataBits, parity, mUartConfig.stopBits)) {
             mUartConfig.parity=parity;
             return true;
          }
          return false;
       }

/*
       set nr of stopbits: 0=1, 1=1.5, 2=2
*/
       @Override
       public boolean setStopBits(int stopBits)
       {
          if(DEBUG_SHOW) Log.d(TAG, "setStopBits");
          if (setLineControl (mUartConfig.dataBits, mUartConfig.parity, stopBits)) {
             mUartConfig.stopBits=stopBits;
             return true;
          }
          return false;
       }
          
         
/*
       set Dtr, Rts to On or Off
*/
       @Override
        public boolean setDtrRts(boolean dtrOn, boolean rtsOn) {

        int val=0;
        if(DEBUG_SHOW) Log.d(TAG, "setDtrRts="+dtrOn+","+rtsOn);
 
        if(rtsOn) val += CP210X_MHS_RTS_ON;
        else val += CP210X_MHS_RTS_OFF;

        if(dtrOn) val += CP210X_MHS_DTR_ON;
        else val += CP210X_MHS_DTR_OFF;

        if (setControlCommand(CP210X_SET_MHS, val, null)) {
           mUartConfig.dtrOn = dtrOn;
           mUartConfig.rtsOn = rtsOn;
           return true;
        }
        return false;
     }
                

        @Override
        public UartConfig getUartConfig() {
                return mUartConfig;
        }

        @Override
        public int getBaudrate() {
                return mUartConfig.baudrate;
        }

        @Override
        public int getDataBits() {
                return mUartConfig.dataBits;
        }

        @Override
        public int getParity() {
                return mUartConfig.parity;
        }

        @Override
        public int getStopBits() {
                return mUartConfig.stopBits;
        }

        @Override
        public boolean getDtr() {
                return mUartConfig.dtrOn;
        }

        @Override
        public boolean getRts() {
                return mUartConfig.rtsOn;
        }

        @Override
        public void clearBuffer() {
                mBuffer.clear();
        }

        @Override
        public int bytesInReadBuffer() {
                return mBuffer.getBufferdLength();
        }

        //////////////////////////////////////////////////////////
        // Listener for reading uart
        //////////////////////////////////////////////////////////
        private List<ReadListener> uartReadListenerList = new ArrayList<ReadListener>();
        private boolean mStopReadListener = false;

        @Override
        public void addReadListener(ReadListener listener) {
                uartReadListenerList.add(listener);
        }

        @Override
        public void clearReadListener() {
                uartReadListenerList.clear();
        }

        @Override
        public void startReadListener() {
                mStopReadListener = false;
        }

        @Override
        public void stopReadListener() {
                mStopReadListener = true;
        }

        private void onRead(int size) {
                if(mStopReadListener) {
                        return;
                }
                for(ReadListener listener : uartReadListenerList) {
                        listener.onRead(size);
                }
        }
        //////////////////////////////////////////////////////////

        /**
         * Transfers int to little endian byte array
         *
         * @param in integer value
         * @param out 4 or less length byte array
         */
        private void intToLittleEndianBytes(int in, byte[] out) {
                if(out == null) {
                        return;
                }
                if(out.length > 4) {
                        return;
                }
                for(int i = 0; i < out.length; i++) {
                        out[i] = (byte) ((in >> (i * 8)) & 0x000000FF);
                }
        }

        /**
         * Transfers little endian byte array to int
         *
         * @param in 4 or less length byte array
         * @return integer value
         */
        private int littleEndianBytesToInt(byte[] in) {
                if(in == null) {
                        return 0;
                }
                if(in.length > 4) {
                        return 0;
                }
                int ret = 0;
                for(int i = 0; i < in.length; i++) {
                        ret |= (((int) in[i]) & 0x000000FF) << (i * 8);
                }
                return ret;
        }

        @Override
        public String getPhysicalConnectionName() {
                return Physicaloid.USB_STRING;
        }

        @Override
        public int getPhysicalConnectionType() {
                return Physicaloid.USB;
        }

        @Override
        public void setDebug(boolean flag) {
                DEBUG_SHOW = flag;
        }
}
