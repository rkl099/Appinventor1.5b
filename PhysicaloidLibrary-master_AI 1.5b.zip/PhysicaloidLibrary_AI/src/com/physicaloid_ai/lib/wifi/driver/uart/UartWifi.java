/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.physicaloid_ai.lib.wifi.driver.uart;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.physicaloid_ai.lib.Physicaloid;
import com.physicaloid_ai.lib.framework.SerialCommunicator;
import com.physicaloid_ai.lib.usb.driver.uart.ReadListener;
import com.physicaloid_ai.lib.usb.driver.uart.UartConfig;
import com.physicaloid_ai.misc.RingBuffer;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;

/**
 *
 * @author xxxajk@gmail.com
 */
/*
   201120        Add bytesInReadBuffer()
   211129        Remove all CTRL code
   211130        rewrite Write method
   211201        Add server
                 Rewrite client
   230120        Change client timeout .5->5sec add closesockets if no connection             
*/

public class UartWifi extends SerialCommunicator {

        private static final String TAG = UartWifi.class.getSimpleName();
        private boolean DEBUG_SHOW = false;
        private UartConfig mUartConfig;
        private static final int RING_BUFFER_SIZE = 1024;
        private static final int READ_BUFFER_SIZE = 256;
        private RingBuffer mBuffer;
        private boolean mReadThreadStop = true;
        private boolean isOpened;
        private boolean isConnected;
        private String SERVER_IP = null; 
        private int DATA_PORT = 0;
        private Socket DATA_socket = null;
        private ServerSocket ClientServerSocket;
        private DataOutputStream DATA_OUT;
        private DataInputStream DATA_IN;
        volatile boolean ClientConnected = false;
        volatile Context me;


        private boolean isNetworkConnected(Context context) {
                if (DEBUG_SHOW) Log.d(TAG, "Network available?");
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                if(netInfo == null) {
                        return false;
                }
                return (netInfo.isConnected() && netInfo.getType() == ConnectivityManager.TYPE_WIFI);
                //return cm.getActiveNetworkInfo() != null;
        }


        public UartWifi(Context context, String host, int Dport ) {
                super(context);
                SERVER_IP = host;
                DATA_PORT = Dport;
                mUartConfig = new UartConfig();
                mBuffer = new RingBuffer(RING_BUFFER_SIZE);
                isOpened = false;
                DATA_socket = null;
                DATA_OUT = null;
                DATA_IN = null;
                me = context;
        }
        
 

        private Runnable Client = new Runnable() {

                InetAddress serverAddr;

                @Override
                @SuppressWarnings("CallToThreadDumpStack")
                public void run() {
                        ClientConnected = false;
                        if (!isNetworkConnected(me)) return;
                        try {
                           serverAddr = InetAddress.getByName(SERVER_IP);
                           if (DEBUG_SHOW) Log.d(TAG,"ClientIP="+SERVER_IP+":"+String.valueOf(DATA_PORT));
                           DATA_socket = new Socket(serverAddr, DATA_PORT);
                           DATA_IN = new DataInputStream(DATA_socket.getInputStream());
                           DATA_OUT = new DataOutputStream(DATA_socket.getOutputStream());
                           Log.d(TAG,"Client: DATA_PORT, DATA_IN, DATA_OUT Connected");
                           ClientConnected = true;
                           return;
                        } catch(Exception ex) {
                           Log.d(TAG, "Cliet not connected");
                           return;
                        }
                      }
        };


        boolean ConnectClient() {
        
           for (int i=1; i<50; i++ ){
               new Thread(Client).start();
               try {
                 Thread.sleep(100);
               } catch(InterruptedException ex) {
               }
               if (ClientConnected) return (true);              
           }
           CloseSockets();
           return (false);
        }


        private Runnable TCP_Server = new Runnable() {

                @Override
                @SuppressWarnings("CallToThreadDumpStack")
                public void run() {
 
                        while( isNetworkConnected(me)) {
                                DATA_socket = null;
                                try {                                        
                                        if (DEBUG_SHOW) Log.d(TAG,"ServerIP="+SERVER_IP+":"+String.valueOf(DATA_PORT));
                                        ClientServerSocket = new ServerSocket(DATA_PORT);
                                        // ClientServerSocket.setSoTimeout (10000);
                                        DATA_socket = ClientServerSocket.accept();
                                        ClientServerSocket.close();
                                        try {
                                           DATA_IN = new DataInputStream(DATA_socket.getInputStream());
                                           DATA_OUT = new DataOutputStream(DATA_socket.getOutputStream());
                                           Log.d(TAG,"Server connected");
                                        } catch(Exception ex) {
                                        };
                                        Log.d(TAG,"Server DATA_PORT Connected");
                                        isConnected=true;
                                } catch(Exception ex) {
                                        Log.d(TAG,"Server ended");
                                        isConnected = false;
                                        return;
                                }
                        }
                        Log.d(TAG,"Server lost netork");
                }
        };


        Thread ServerThread = new Thread(TCP_Server);
        
        @Override
        public boolean open() {
                if(!isOpened) {
                    Log.d (TAG, "Open: IP="+SERVER_IP+":"+String.valueOf(DATA_PORT));
                    if  ((SERVER_IP == null) || SERVER_IP.isEmpty() ) { 
                        //server
                        if (DEBUG_SHOW) Log.d(TAG,"Open: Start Serverthread");
                        ServerThread.start();                    
                    }
                    else { 
                        // client
                        if (DEBUG_SHOW) Log.d(TAG,"Open: Start Client");
                        if (!ConnectClient()) {
                           return false;
                        } 
                        isConnected = true;                          
                   }
                   startRead();
                   isOpened = true;
                }
                return true;
        }
        
        
        private void CloseSockets() {
 
                Log.d(TAG,"CloseSockets");
                
                if(DATA_OUT != null) {
                        try {
                                DATA_OUT.close();
                        } catch(Exception ex) {
                                Log.d(TAG, ex.toString());
                                ex.printStackTrace();
                        }
                        DATA_OUT = null;
                }
                if(DATA_IN != null) {
                        try {
                                DATA_IN.close();
                        } catch(Exception ex) {
                                Log.d(TAG, ex.toString());
                                ex.printStackTrace();
                        }
                        DATA_IN = null;
                }

                if(DATA_socket != null) {
                        try {
                                DATA_socket.close();
                        } catch(Exception ex) {
                                Log.d(TAG, ex.toString());
                                ex.printStackTrace();
                        }
                        DATA_socket = null;
                }

                if(ClientServerSocket != null) {
                        try {
                                ClientServerSocket.close();
                        } catch(Exception ex) {
                                Log.d(TAG, ex.toString());
                                ex.printStackTrace();
                        }
                        ClientServerSocket = null;
                }
                if (DEBUG_SHOW) Log.d(TAG,"End Close");
        } 
           

        @Override
        @SuppressWarnings({"CallToThreadDumpStack", "SleepWhileInLoop"})
        public boolean close() {
                Log.d(TAG,"Close");
                stopRead();
                isOpened = false;
                ClientConnected = false;
                isConnected = false;
                CloseSockets();
                return true;
        }


        @Override
        public int read(byte[] buf, int size) {
                return mBuffer.get(buf, size);
        }


        @Override
        @SuppressWarnings("CallToThreadDumpStack")
        public int write(final byte[] buf, final int size) {
 
                 int ret = 0;
                 
                 Runnable WSocket = new Runnable(){ 
                
                   @Override 
                   public void run(){ 
                      try {
                        if (DEBUG_SHOW) Log.d(TAG,"write size:"+String.valueOf(size));                
                        DATA_OUT.write(buf, 0, size);
                        if (DEBUG_SHOW) Log.d(TAG, "*write flush");
                        DATA_OUT.flush();
                      } catch(Exception ex) {
                        if (DEBUG_SHOW) Log.d(TAG, "*write exception");
                        Log.d(TAG, ex.toString());
                        ex.printStackTrace();
                        isConnected = false;
                        return;
                      }
                    } 
                 }; 

                if(buf == null) {
                        return 0;
                }
                if (DATA_OUT == null) return 0;
                Thread writeSocket = new Thread(WSocket); 

                try {
                    writeSocket.start();
                    writeSocket.join(2000);   //wait to complete
                } catch(Exception ex){
                    ret = 0;
                };   
                if (DEBUG_SHOW) Log.d(TAG, "*write bytes end");   
                           
                return ret;
        }


        @Override
        @SuppressWarnings("CallToThreadDumpStack")
        public boolean setBaudrate(int baudrate) {
                mUartConfig.baudrate = baudrate;
                return true;
        }


        @Override
        public boolean setDataBits(int dataBits) {
                // We don't do this...
                mUartConfig.dataBits = dataBits;
                return true;
        }


        @Override
        public boolean setParity(int parity) {
                // We don't do this...
                mUartConfig.parity = parity;
                return true;
        }


        @Override
        public boolean setStopBits(int stopBits) {
                // We don't do this...
                mUartConfig.stopBits = stopBits;
                return true;
        }


        @Override
        @SuppressWarnings("CallToThreadDumpStack")
        public boolean setDtrRts(boolean dtrOn, boolean rtsOn) {
                mUartConfig.dtrOn = dtrOn;
                mUartConfig.rtsOn = rtsOn;
                return true;
        }


        //////////////////////////////////////////////////////////
        /**
         * Sets Uart configurations
         *
         * @param config configurations
         * @return true : successful, false : fail
         */
        public boolean setUartConfig(UartConfig config) {
                boolean res;
                boolean ret = true;
                if(mUartConfig.baudrate != config.baudrate) {
                        res = setBaudrate(config.baudrate);
                        ret = ret && res;
                }

                if(mUartConfig.dataBits != config.dataBits) {
                        res = setDataBits(config.dataBits);
                        ret = ret && res;
                }

                if(mUartConfig.parity != config.parity) {
                        res = setParity(config.parity);
                        ret = ret && res;
                }

                if(mUartConfig.stopBits != config.stopBits) {
                        res = setStopBits(config.stopBits);
                        ret = ret && res;
                }

                if(mUartConfig.dtrOn != config.dtrOn
                        || mUartConfig.rtsOn != config.rtsOn) {
                        res = setDtrRts(config.dtrOn, config.rtsOn);
                        ret = ret && res;
                }

                return ret;
        }


        @Override
        public boolean isOpened() {
                return isOpened;
        }

        @Override
        public boolean isConnected() {
           return isConnected;
        }



        @Override
        public UartConfig getUartConfig() {
                return mUartConfig;
        }


        @Override
        public int getBaudrate() {
                return mUartConfig.baudrate;
        }


        @Override
        public int getDataBits() {
                return mUartConfig.dataBits;
        }


        @Override
        public int getParity() {
                return mUartConfig.parity;
        }


        @Override
        public int getStopBits() {
                return mUartConfig.stopBits;
        }


        @Override
        public boolean getDtr() {
                return mUartConfig.dtrOn;
        }


        @Override
        public boolean getRts() {
                return mUartConfig.rtsOn;
        }


        @Override
        public void clearBuffer() {
                mBuffer.clear();
        }

        //////////////////////////////////////////////////////////
        // Listener for reading uart
        //////////////////////////////////////////////////////////
        private List<ReadListener> uartReadListenerList = new ArrayList<ReadListener>();
        private boolean mStopReadListener = false;

        @Override
        public void addReadListener(ReadListener listener) {
                uartReadListenerList.add(listener);
        }


        @Override
        public void clearReadListener() {
                uartReadListenerList.clear();
        }


        @Override
        public void startReadListener() {
                mStopReadListener = false;
        }


        @Override
        public void stopReadListener() {
                mStopReadListener = true;
        }


        private void onRead(int size) {
                if(mStopReadListener) {
                        return;
                }
                for(ReadListener listener : uartReadListenerList) {
                        listener.onRead(size);
                }
        }
        //////////////////////////////////////////////////////////

        private void stopRead() {
                mReadThreadStop = true;
        }


        private void startRead() {
                if(mReadThreadStop) {
                        mReadThreadStop = false;
                        new Thread(mLoop).start();
                }
        }
 
 
        private Runnable mLoop = new Runnable() {

                @Override
                @SuppressWarnings("SleepWhileInLoop")
                public void run() {
                        int len;
                        int ret;
                        byte[] rbuf = new byte[READ_BUFFER_SIZE];
                        android.os.Process.setThreadPriority(-20);
                        Log.d(TAG,"Read: Start thread");
                        mBuffer.clear();
                        for(;;) {
                                if(mReadThreadStop) {
                                        return;
                                }

                                try {
                                    Thread.sleep(10);
                                } catch(Exception ex) {
                                }

                                try {
                                   if (DATA_IN != null) {
                                       len = 0;
                                       /* Test if connected, > -1 or exception */ 
                                       ret = DATA_IN.read(rbuf, len, 1);
                                       if (ret<0) isConnected = false;
                                       if (ret>0) len++;
                                               
                                       while(DATA_IN.available() > 0 && len < READ_BUFFER_SIZE) {
                                              DATA_IN.read(rbuf, len, 1);
                                              len++;
                                       }

                                       if(len > 0) {
                                              mBuffer.add(rbuf, len);
                                              onRead(len);
                                       }
                                   }

                                } catch(IOException ex) {
                                try {
                                    Thread.sleep(1000);
                                } catch(InterruptedException exx) {
                                }
                                isConnected = false;
                            }
                        }
                } // end of run()
        }; // end of runnable


        @Override
        public int bytesInReadBuffer() {
                return mBuffer.getBufferdLength();
        }


        @Override
        public String getPhysicalConnectionName() {
                return Physicaloid.WIFI_STRING;
        }


        @Override
        public int getPhysicalConnectionType() {
                return Physicaloid.WIFI;
        }


        @Override
        public void setDebug(boolean flag) {
                DEBUG_SHOW = flag;
        }
}
